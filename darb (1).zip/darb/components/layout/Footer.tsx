export default function Footer() {
  return (
    <footer className="mt-16 bg-navy text-white/80">
      <div className="mx-auto max-w-6xl px-4 py-8 text-sm">
        <p className="font-bold text-white">دَرْب — مشوارك للجامعة، صار أوضح.</p>
        <p className="mt-2">نسخة تجريبية (MVP). لا ترخيص نقل، ولا شراكات مع جامعات، ولا حجوزات أو مدفوعات حقيقية.</p>
      </div>
    </footer>
  );
}
