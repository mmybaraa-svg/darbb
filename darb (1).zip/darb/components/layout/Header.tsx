import Link from "next/link";
import { Route } from "lucide-react";
const links = [["/routes", "المسارات"], ["/request", "اطلب مشوار"], ["/dashboard", "لوحتي"], ["/provider", "مزوّد"], ["/admin", "الإدارة"]];
export function Wordmark() {
  return <Link href="/" className="flex items-center gap-2 text-xl font-extrabold text-navy"><Route className="text-teal" aria-hidden /> دَرْب <span className="text-sm font-semibold text-muted">DARB</span></Link>;
}
export default function Header() {
  return (
    <header className="sticky top-0 z-20 border-b border-navy/10 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
        <Wordmark />
        <nav aria-label="التنقل الرئيسي" className="flex flex-wrap items-center gap-4 text-sm font-bold text-navy">
          {links.map(([h, t]) => <Link key={h} href={h} className="hover:text-teal">{t}</Link>)}
          <Link href="/login" className="btn-primary !py-1.5">دخول</Link>
        </nav>
      </div>
    </header>
  );
}
