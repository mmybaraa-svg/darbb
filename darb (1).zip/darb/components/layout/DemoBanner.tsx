import { isDemoMode } from "@/lib/supabase/config";
export default function DemoBanner() {
  if (!isDemoMode) return null;
  return <div role="status" className="bg-teal-light/40 px-4 py-2 text-center text-sm font-bold text-navy">وضع تجريبي — البيانات المعروضة لأغراض الاختبار فقط.</div>;
}
