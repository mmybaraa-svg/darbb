import Link from "next/link";
import { Clock, MapPin, GraduationCap } from "lucide-react";
import type { DemoRoute } from "@/lib/demo/data";
export default function RouteCard({ r }: { r: DemoRoute }) {
  return (
    <article className="card flex flex-col gap-3">
      <span className="w-fit rounded-full bg-teal-light/40 px-3 py-0.5 text-xs font-bold text-navy">تجريبي</span>
      <h3 className="text-lg font-extrabold text-navy">{r.origin} ← {r.destination}</h3>
      <p className="flex items-center gap-2 text-sm text-muted"><GraduationCap size={16} aria-hidden />{r.university}</p>
      <p className="flex items-center gap-2 text-sm text-muted"><MapPin size={16} aria-hidden />{r.pickup}</p>
      <p className="flex items-center gap-2 text-sm text-muted"><Clock size={16} aria-hidden />{r.departure} · {r.days}</p>
      <Link href={`/routes/${r.id}`} className="btn-ghost mt-auto">التفاصيل</Link>
    </article>
  );
}
