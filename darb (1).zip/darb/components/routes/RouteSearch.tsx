"use client";
import { useState } from "react";
import { demoRoutes, areas, universities } from "@/lib/demo/data";
import { filterRoutes } from "@/lib/utils/filter";
import RouteCard from "./RouteCard";
export default function RouteSearch({ initialQ = "" }: { initialQ?: string }) {
  const [q, setQ] = useState(initialQ);
  const [origin, setOrigin] = useState("");
  const [university, setUniversity] = useState("");
  const [time, setTime] = useState("");
  const list = filterRoutes(demoRoutes, { q, origin, university, time });
  return (
    <div>
      <div className="card mb-6 grid gap-3 md:grid-cols-4">
        <div><label className="label" htmlFor="q">بحث</label><input id="q" className="input" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <div><label className="label" htmlFor="o">منطقة الانطلاق</label><select id="o" className="input" value={origin} onChange={(e) => setOrigin(e.target.value)}><option value="">الكل</option>{areas.map((a) => <option key={a}>{a}</option>)}</select></div>
        <div><label className="label" htmlFor="u">الجامعة</label><select id="u" className="input" value={university} onChange={(e) => setUniversity(e.target.value)}><option value="">الكل</option>{universities.map((a) => <option key={a}>{a}</option>)}</select></div>
        <div><label className="label" htmlFor="t">الانطلاق بعد</label><input id="t" type="time" className="input" value={time} onChange={(e) => setTime(e.target.value)} /></div>
      </div>
      {list.length === 0 ? <p className="card text-center text-muted">لا توجد مسارات مطابقة.</p> :
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{list.map((r) => <RouteCard key={r.id} r={r} />)}</div>}
    </div>
  );
}
