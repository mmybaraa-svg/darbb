"use client";
import { useState } from "react";
import { areas, universities } from "@/lib/demo/data";
import { validateRequest, type RequestForm } from "@/lib/utils/validate";
const steps = ["منطقة الانطلاق", "الجامعة", "التاريخ", "الوقت", "عدد الركاب", "ملاحظات", "مراجعة"];
export default function RequestPage() {
  const [i, setI] = useState(0);
  const [f, setF] = useState<RequestForm>({ origin: "", university: "", date: "", time: "", passengers: 1, notes: "" });
  const [errs, setErrs] = useState<Record<string, string>>({});
  const [done, setDone] = useState<string | null>(null);
  const keys = ["origin", "university", "date", "time", "passengers", "notes"] as const;
  const set = (k: keyof RequestForm, v: string | number) => setF({ ...f, [k]: v });
  function next() {
    const e = validateRequest(f); const k = keys[i];
    if (k && e[k]) { setErrs({ [k]: e[k] }); return; }
    setErrs({}); setI(i + 1);
  }
  function submit() {
    const e = validateRequest(f);
    if (Object.keys(e).length) { setErrs(e); return; }
    const rec = { id: "DEMO-" + Date.now().toString(36).toUpperCase(), ...f, status: "تجريبي", demo: true };
    try { const old = JSON.parse(localStorage.getItem("darb_demo_requests") ?? "[]"); localStorage.setItem("darb_demo_requests", JSON.stringify([rec, ...old])); } catch {}
    setDone(rec.id);
  }
  if (done) return <div className="card max-w-xl" role="status"><h1 className="text-xl font-extrabold text-navy">تم إرسال الطلب التجريبي بنجاح. هذا الطلب لا يمثل حجز رحلة حقيقية.</h1><p className="mt-2 text-muted">رقم الطلب التجريبي: {done}</p></div>;
  const err = (k: string) => errs[k] && <p role="alert" className="mt-1 text-sm text-red-700">{errs[k]}</p>;
  return (
    <div className="card max-w-xl">
      <h1 className="text-2xl font-extrabold text-navy">طلب مشوار (تجريبي)</h1>
      <p className="mb-4 text-sm text-muted">الخطوة {i + 1} من {steps.length}: {steps[i]}</p>
      {i === 0 && <><label className="label" htmlFor="f">منطقة الانطلاق</label><select id="f" className="input" value={f.origin} onChange={(e) => set("origin", e.target.value)}><option value="">اختر</option>{areas.map((a) => <option key={a}>{a}</option>)}</select>{err("origin")}</>}
      {i === 1 && <><label className="label" htmlFor="f">الجامعة</label><select id="f" className="input" value={f.university} onChange={(e) => set("university", e.target.value)}><option value="">اختر</option>{universities.map((a) => <option key={a}>{a}</option>)}</select>{err("university")}</>}
      {i === 2 && <><label className="label" htmlFor="f">التاريخ</label><input id="f" type="date" className="input" value={f.date} onChange={(e) => set("date", e.target.value)} />{err("date")}</>}
      {i === 3 && <><label className="label" htmlFor="f">الوقت</label><input id="f" type="time" className="input" value={f.time} onChange={(e) => set("time", e.target.value)} />{err("time")}</>}
      {i === 4 && <><label className="label" htmlFor="f">عدد الركاب</label><input id="f" type="number" min={1} max={6} className="input" value={f.passengers} onChange={(e) => set("passengers", Number(e.target.value))} />{err("passengers")}</>}
      {i === 5 && <><label className="label" htmlFor="f">ملاحظات (اختياري)</label><textarea id="f" className="input" rows={3} value={f.notes} onChange={(e) => set("notes", e.target.value)} />{err("notes")}</>}
      {i === 6 && <dl className="space-y-1 text-sm">{[["الانطلاق", f.origin], ["الجامعة", f.university], ["التاريخ", f.date], ["الوقت", f.time], ["الركاب", f.passengers], ["ملاحظات", f.notes || "—"]].map(([k, v]) => <div key={k as string} className="flex justify-between"><dt className="text-muted">{k}</dt><dd className="font-bold">{v}</dd></div>)}</dl>}
      <div className="mt-6 flex justify-between">
        <button className="btn-ghost" disabled={i === 0} onClick={() => setI(i - 1)}>السابق</button>
        {i < 6 ? <button className="btn-primary" onClick={next}>التالي</button> : <button className="btn-primary" onClick={submit}>إرسال الطلب التجريبي</button>}
      </div>
    </div>
  );
}
