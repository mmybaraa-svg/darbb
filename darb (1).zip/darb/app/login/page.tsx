import { isDemoMode } from "@/lib/supabase/config";
export default function Page() {
  return (
    <div className="card max-w-md">
      <h1 className="mb-4 text-2xl font-extrabold text-navy">تسجيل الدخول</h1>
      {isDemoMode && <p role="status" className="mb-4 rounded-xl bg-teal-light/40 p-3 text-sm font-bold text-navy">الوضع التجريبي: تسجيل الدخول الحقيقي غير مفعّل. اضبط Supabase لتفعيله.</p>}
      <form className="space-y-3" action="#">
        
        <label className="label" htmlFor="email">البريد الإلكتروني</label><input id="email" type="email" className="input" disabled={isDemoMode} />
        <label className="label" htmlFor="pw">كلمة المرور</label><input id="pw" type="password" className="input" disabled={isDemoMode} />
        <button className="btn-primary w-full" disabled={isDemoMode}>تسجيل الدخول</button>
      </form>
    </div>
  );
}
