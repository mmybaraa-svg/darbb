export default function Page() {
  return (<div className="card max-w-2xl"><h1 className="mb-3 text-2xl font-extrabold text-navy">لوحة الإدارة (بيانات تجريبية)</h1><p className="text-muted">مستخدمون: — · مسارات: 4 · طلبات: محلية. بيانات تجريبية. الصلاحية الحقيقية تُفرض من الخادم عند تفعيل Supabase.</p></div>);
}
