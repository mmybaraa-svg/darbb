export default function Page() {
  return (<div className="card max-w-2xl"><h1 className="mb-3 text-2xl font-extrabold text-navy">لوحة المزوّد (نموذج أولي)</h1><p className="text-muted">هذه الوظائف تجريبية ومعطّلة تشغيلياً: الملف، حالة التحقق، المسارات، الطلبات المؤهلة، وقبول/رفض محاكى. لا عمليات نقل حقيقية.</p></div>);
}
