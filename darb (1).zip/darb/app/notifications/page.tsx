export default function Page() {
  return (<div className="card max-w-2xl"><h1 className="mb-3 text-2xl font-extrabold text-navy">الإشعارات</h1><p className="text-muted">إشعارات داخل الموقع فقط. الإشعارات الفورية (Push) غير مفعّلة.</p></div>);
}
