export default function Page() {
  return (<div className="card max-w-2xl"><h1 className="mb-3 text-2xl font-extrabold text-navy">الملف الشخصي</h1><p className="text-muted">الاسم، البريد، الهاتف (اختياري)، الجامعة، المنطقة — تُحفظ عند تفعيل Supabase.</p></div>);
}
