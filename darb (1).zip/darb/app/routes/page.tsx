import RouteSearch from "@/components/routes/RouteSearch";
export default function RoutesPage({ searchParams }: { searchParams: { q?: string } }) {
  return (<><h1 className="mb-6 text-3xl font-extrabold text-navy">المسارات</h1><RouteSearch initialQ={searchParams.q ?? ""} /></>);
}
