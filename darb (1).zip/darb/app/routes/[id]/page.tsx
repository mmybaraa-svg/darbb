import Link from "next/link";
import { notFound } from "next/navigation";
import { demoRoutes } from "@/lib/demo/data";
export default function RouteDetails({ params }: { params: { id: string } }) {
  const r = demoRoutes.find((x) => x.id === params.id);
  if (!r) notFound();
  const rows = [["الانطلاق", r.origin], ["الوجهة", r.destination], ["الجامعة", r.university], ["نقطة التجمع", r.pickup], ["وقت الانطلاق", r.departure], ["الأيام", r.days], ["المدة التقديرية", "غير متوفرة"], ["المقاعد المتاحة", "غير متوفرة (بيانات تجريبية)"], ["الحالة", "مسار تجريبي — ليس خدمة حقيقية"]];
  return (
    <div className="card max-w-2xl">
      <h1 className="mb-4 text-2xl font-extrabold text-navy">{r.origin} ← {r.destination}</h1>
      <dl className="divide-y divide-navy/10">{rows.map(([k, v]) => <div key={k} className="flex justify-between py-2"><dt className="text-muted">{k}</dt><dd className="font-bold">{v}</dd></div>)}</dl>
      <Link href="/request" className="btn-primary mt-6">أرسل طلباً تجريبياً</Link>
    </div>
  );
}
