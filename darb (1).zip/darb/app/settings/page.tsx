export default function Page() {
  return (<div className="card max-w-2xl"><h1 className="mb-3 text-2xl font-extrabold text-navy">الإعدادات</h1><p className="text-muted">اللغة (العربية)، الإشعارات، الخصوصية، طلب حذف الحساب، تسجيل الخروج — تُفعَّل مع Supabase.</p></div>);
}
