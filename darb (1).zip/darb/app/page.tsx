import Link from "next/link";
import { Search, CalendarCheck, Bus } from "lucide-react";
import { areas, universities, demoRoutes } from "@/lib/demo/data";
import RouteCard from "@/components/routes/RouteCard";
const steps = [[Search, "ابحث عن مسارك", "اختر منطقتك وجامعتك."], [CalendarCheck, "أرسل طلبك", "حدّد التاريخ والوقت وعدد الركاب."], [Bus, "تابع الحالة", "تصلك تحديثات الطلب داخل الموقع."]] as const;
const faq = [["هل هذا حجز حقيقي؟", "لا. النسخة الحالية تجريبية ولا تُنفّذ حجوزات أو مدفوعات."], ["هل الخدمة مرخّصة؟", "لا ندّعي أي ترخيص. التشغيل الحقيقي مؤجل حتى التحقق من المتطلبات في الأردن."]];
export default function Home() {
  return (
    <div className="space-y-16">
      <section className="rounded-3xl bg-navy px-6 py-14 text-center text-white">
        <h1 className="text-4xl font-extrabold md:text-5xl">مشوارك للجامعة، صار <span className="text-teal-light">أوضح</span>.</h1>
        <p className="mx-auto mt-4 max-w-xl text-white/80">منصة لتنسيق مواصلات الطلبة من قرى لواء الكورة إلى الجامعات.</p>
        <form action="/routes" className="mx-auto mt-8 flex max-w-lg gap-2">
          <input name="q" aria-label="ابحث عن مسار" placeholder="ابحث: كفرعوان، اليرموك…" className="input" />
          <button className="btn-primary">بحث</button>
        </form>
        <Link href="/request" className="btn-ghost mt-4">اطلب مشوارك</Link>
      </section>
      <section><h2 className="mb-6 text-2xl font-extrabold text-navy">كيف يعمل دَرْب</h2>
        <div className="grid gap-4 md:grid-cols-3">{steps.map(([I, t, d]) => <div key={t} className="card"><I className="text-teal" aria-hidden /><h3 className="mt-2 font-extrabold text-navy">{t}</h3><p className="text-sm text-muted">{d}</p></div>)}</div></section>
      <section><h2 className="mb-6 text-2xl font-extrabold text-navy">مسارات تجريبية</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">{demoRoutes.map((r) => <RouteCard key={r.id} r={r} />)}</div></section>
      <section className="grid gap-4 md:grid-cols-2">
        <div className="card"><h2 className="font-extrabold text-navy">الجامعات</h2><p className="mt-2 text-sm text-muted">{universities.join(" · ")}</p></div>
        <div className="card"><h2 className="font-extrabold text-navy">المناطق</h2><p className="mt-2 text-sm text-muted">{areas.join(" · ")}</p></div>
      </section>
      <section><h2 className="mb-4 text-2xl font-extrabold text-navy">أسئلة شائعة</h2>
        {faq.map(([q, a]) => <details key={q} className="card mb-2"><summary className="cursor-pointer font-bold text-navy">{q}</summary><p className="mt-2 text-sm text-muted">{a}</p></details>)}</section>
    </div>
  );
}
