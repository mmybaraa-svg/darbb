"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { demoNotifications } from "@/lib/demo/data";
type Req = { id: string; origin: string; university: string; date: string; time: string; passengers: number; status: string };
export default function Dashboard() {
  const [reqs, setReqs] = useState<Req[]>([]);
  useEffect(() => { try { setReqs(JSON.parse(localStorage.getItem("darb_demo_requests") ?? "[]")); } catch {} }, []);
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-extrabold text-navy">أهلاً بك 👋 (حساب تجريبي)</h1>
      <section className="card"><h2 className="mb-3 font-extrabold text-navy">طلباتي</h2>
        {reqs.length === 0 ? <p className="text-muted">لا توجد طلبات بعد. <Link href="/request" className="font-bold text-teal">أرسل طلباً تجريبياً</Link></p> :
          <ul className="divide-y divide-navy/10">{reqs.map((r) => <li key={r.id} className="py-2 text-sm"><b>{r.id}</b> · {r.origin} ← {r.university} · {r.date} {r.time} · {r.passengers} ركاب · <span className="text-muted">{r.status}</span></li>)}</ul>}
      </section>
      <section className="card"><h2 className="mb-3 font-extrabold text-navy">الإشعارات</h2>{demoNotifications.map((n) => <p key={n.id} className="text-sm"><b>{n.title}</b> — {n.body}</p>)}</section>
    </div>
  );
}
