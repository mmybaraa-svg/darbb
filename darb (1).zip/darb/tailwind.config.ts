import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: "#142B3A", teal: { DEFAULT: "#168A83", light: "#8FE0D2" },
        surface: "#F5F7FA", ink: "#17212B", muted: "#667085",
      },
      fontFamily: { sans: ["var(--font-tajawal)", "system-ui", "sans-serif"] },
      boxShadow: { card: "0 1px 3px rgba(20,43,58,.06), 0 8px 24px rgba(20,43,58,.06)" },
    },
  },
  plugins: [],
};
export default config;
