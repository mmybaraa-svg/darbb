-- FICTIONAL demo data only.
insert into universities(name) values ('جامعة اليرموك'),('جامعة العلوم والتكنولوجيا الأردنية'),('جامعة إربد الأهلية') on conflict do nothing;
insert into areas(name) values ('كفرعوان'),('كفر الماء'),('طبنة'),('سال') on conflict do nothing;
