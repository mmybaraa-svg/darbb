create extension if not exists pgcrypto;
create type app_role as enum ('student','provider','admin');
create type request_status as enum ('pending','upcoming','completed','cancelled');

create table profiles (id uuid primary key references auth.users on delete cascade, full_name text, phone text, university_id uuid, area_id uuid, created_at timestamptz default now(), updated_at timestamptz default now());
create table user_roles (user_id uuid references auth.users on delete cascade, role app_role not null default 'student', primary key (user_id, role));
create table universities (id uuid primary key default gen_random_uuid(), name text not null unique, created_at timestamptz default now());
create table areas (id uuid primary key default gen_random_uuid(), name text not null unique, created_at timestamptz default now());
create table routes (id uuid primary key default gen_random_uuid(), area_id uuid not null references areas, university_id uuid not null references universities, pickup text not null, departure_time time not null, active boolean not null default false, is_demo boolean not null default true, created_at timestamptz default now(), updated_at timestamptz default now());
create table trip_requests (id uuid primary key default gen_random_uuid(), student_id uuid not null references auth.users on delete cascade, area_id uuid references areas, university_id uuid references universities, trip_date date not null, trip_time time not null, passengers int not null check (passengers between 1 and 6), notes text check (char_length(notes) <= 300), status request_status not null default 'pending', created_at timestamptz default now(), updated_at timestamptz default now());
create table notifications (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users on delete cascade, title text not null, body text, read boolean default false, created_at timestamptz default now());
create table saved_routes (user_id uuid references auth.users on delete cascade, route_id uuid references routes on delete cascade, primary key (user_id, route_id));
create table provider_profiles (user_id uuid primary key references auth.users on delete cascade, business_name text, verified boolean not null default false, created_at timestamptz default now());
create table audit_logs (id uuid primary key default gen_random_uuid(), actor_id uuid, action text not null, detail jsonb, created_at timestamptz default now());
create table app_settings (key text primary key, value jsonb, updated_at timestamptz default now());
create index on trip_requests (student_id); create index on notifications (user_id); create index on routes (area_id, university_id);

create or replace function is_admin() returns boolean language sql security definer stable set search_path = public as
$$ select exists (select 1 from user_roles where user_id = auth.uid() and role = 'admin') $$;

-- New users always get role 'student'; roles can only be changed by admins.
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path = public as
$$ begin insert into profiles(id) values (new.id); insert into user_roles(user_id, role) values (new.id, 'student'); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

do $$ declare t text; begin
  foreach t in array array['profiles','user_roles','universities','areas','routes','trip_requests','notifications','saved_routes','provider_profiles','audit_logs','app_settings'] loop
    execute format('alter table %I enable row level security', t); end loop; end $$;

create policy "own profile read" on profiles for select using (id = auth.uid() or is_admin());
create policy "own profile update" on profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy "own roles read" on user_roles for select using (user_id = auth.uid() or is_admin());
create policy "admin manages roles" on user_roles for all using (is_admin()) with check (is_admin());
create policy "public read universities" on universities for select using (true);
create policy "public read areas" on areas for select using (true);
create policy "admin write universities" on universities for all using (is_admin()) with check (is_admin());
create policy "admin write areas" on areas for all using (is_admin()) with check (is_admin());
create policy "read routes" on routes for select using (true);
create policy "admin write routes" on routes for all using (is_admin()) with check (is_admin());
create policy "own requests read" on trip_requests for select using (student_id = auth.uid() or is_admin());
create policy "own requests insert" on trip_requests for insert with check (student_id = auth.uid() and status = 'pending');
create policy "own requests cancel" on trip_requests for update using (student_id = auth.uid()) with check (student_id = auth.uid() and status = 'cancelled');
create policy "own notifications" on notifications for select using (user_id = auth.uid());
create policy "own notifications mark read" on notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own saved routes" on saved_routes for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own provider read" on provider_profiles for select using (user_id = auth.uid() or is_admin());
create policy "admin manages providers" on provider_profiles for all using (is_admin()) with check (is_admin());
create policy "admin reads audit" on audit_logs for select using (is_admin());
create policy "admin settings" on app_settings for all using (is_admin()) with check (is_admin());
