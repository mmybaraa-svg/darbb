# دَرْب | DARB — مشوارك للجامعة، صار أوضح.

موقع ويب (Next.js + TypeScript + Tailwind + Supabase). نسخة MVP تجريبية.

## المتطلبات
Windows، Node.js LTS، VS Code، Chrome أو Edge.

## التشغيل
```bash
npm install
npm run dev
```
افتح http://localhost:3000

## التشغيل عبر الشبكة المحلية (LAN)
```bash
npm run dev:network
```
ثم في PowerShell: `ipconfig` وابحث عن **IPv4 Address** (مثلاً 192.168.1.10)، وافتح من جهاز آخر على نفس الشبكة:
`http://YOUR-PC-IP:3000`

هذا يعمل على نفس الشبكة فقط، وليس عبر الإنترنت. عند ظهور تنبيه Windows Firewall اسمح لـ Node.js على الشبكات **الخاصة** فقط؛ لا تُعطّل الجدار الناري.

## الإنترنت العام
يتطلب نشر المشروع (مثل Vercel) ودومين اختيارياً. لا يُنشر تلقائياً.

## الوضع التجريبي (DEMO MODE)
إذا لم تُضبط متغيرات Supabase يعمل الموقع ببيانات وهمية، ويظهر شريط "وضع تجريبي". الطلبات تُحفظ في متصفحك فقط وليست حجوزات.

## ضبط Supabase
1. انسخ `.env.example` إلى `.env.local` وأضف `NEXT_PUBLIC_SUPABASE_URL` و `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
2. نفّذ `supabase/migrations/0001_init.sql` ثم `supabase/seed.sql` من لوحة Supabase (SQL Editor).
3. لتعيين مدير: أضف صفاً `admin` في `user_roles` من لوحة Supabase (لا يمكن للمستخدم ترقية نفسه).

## الأوامر
`npm run build` · `npm start` · `npm run lint` · `npm test`

## حالة الاكتمال
انظر "الأعمال المتبقية" في ردّ البناء. صفحات الإدارة والمزوّد والملف الشخصي حالياً هياكل أولية.
