import { describe, it, expect } from "vitest";
import { filterRoutes } from "../lib/utils/filter";
import { validateRequest } from "../lib/utils/validate";
import { demoRoutes } from "../lib/demo/data";
describe("filterRoutes", () => {
  it("filters by origin", () => expect(filterRoutes(demoRoutes, { origin: "طبنة" })).toHaveLength(1));
  it("returns all with no filters", () => expect(filterRoutes(demoRoutes, {})).toHaveLength(demoRoutes.length));
});
describe("validateRequest", () => {
  const now = new Date("2026-10-07T10:00:00");
  const ok = { origin: "طبنة", university: "جامعة اليرموك", date: "2026-10-08", time: "07:00", passengers: 1 };
  it("accepts valid", () => expect(validateRequest(ok, now)).toEqual({}));
  it("rejects past date", () => expect(validateRequest({ ...ok, date: "2026-10-01" }, now).date).toBeTruthy());
  it("rejects bad passenger count", () => expect(validateRequest({ ...ok, passengers: 9 }, now).passengers).toBeTruthy());
});
