export type RequestForm = { origin: string; university: string; date: string; time: string; passengers: number; notes?: string };
export function validateRequest(f: RequestForm, now = new Date()): Record<string, string> {
  const e: Record<string, string> = {};
  if (!f.origin) e.origin = "اختر منطقة الانطلاق";
  if (!f.university) e.university = "اختر الجامعة";
  if (!f.date) e.date = "اختر التاريخ";
  else {
    const d = new Date(f.date + "T00:00:00"); const today = new Date(now); today.setHours(0, 0, 0, 0);
    if (Number.isNaN(d.getTime()) || d < today) e.date = "لا يمكن اختيار تاريخ سابق";
  }
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(f.time)) e.time = "أدخل وقتاً صحيحاً";
  if (!Number.isInteger(f.passengers) || f.passengers < 1 || f.passengers > 6) e.passengers = "عدد الركاب بين 1 و 6";
  if ((f.notes ?? "").length > 300) e.notes = "الملاحظات طويلة جداً (الحد 300 حرف)";
  return e;
}
