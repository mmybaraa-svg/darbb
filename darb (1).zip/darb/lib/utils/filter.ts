import type { DemoRoute } from "@/lib/demo/data";
export type RouteFilters = { q?: string; origin?: string; university?: string; time?: string };
export function filterRoutes(routes: DemoRoute[], f: RouteFilters): DemoRoute[] {
  const q = f.q?.trim();
  return routes.filter((r) =>
    (!q || [r.origin, r.destination, r.university, r.pickup].some((s) => s.includes(q))) &&
    (!f.origin || r.origin === f.origin) &&
    (!f.university || r.university === f.university) &&
    (!f.time || r.departure >= f.time)
  );
}
