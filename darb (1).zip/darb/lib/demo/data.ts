// All data here is FICTIONAL and for testing only. Not real transport services.
export type DemoRoute = {
  id: string; origin: string; destination: string; university: string;
  pickup: string; departure: string; days: string; durationMin?: number; status: "draft-demo";
};
export const universities = ["جامعة اليرموك", "جامعة العلوم والتكنولوجيا الأردنية", "جامعة إربد الأهلية"];
export const areas = ["كفرعوان", "كفر الماء", "طبنة", "سال"];
export const demoRoutes: DemoRoute[] = [
  { id: "demo-1", origin: "كفرعوان", destination: "إربد", university: "جامعة اليرموك", pickup: "الدوار الرئيسي (نقطة تجريبية)", departure: "06:45", days: "الأحد – الخميس", status: "draft-demo" },
  { id: "demo-2", origin: "كفر الماء", destination: "إربد", university: "جامعة العلوم والتكنولوجيا الأردنية", pickup: "أمام المدرسة (نقطة تجريبية)", departure: "06:30", days: "الأحد – الخميس", status: "draft-demo" },
  { id: "demo-3", origin: "طبنة", destination: "إربد", university: "جامعة اليرموك", pickup: "المسجد الكبير (نقطة تجريبية)", departure: "07:00", days: "الأحد – الأربعاء", status: "draft-demo" },
  { id: "demo-4", origin: "سال", destination: "إربد", university: "جامعة إربد الأهلية", pickup: "ساحة البلدة (نقطة تجريبية)", departure: "07:15", days: "الأحد – الخميس", status: "draft-demo" },
];
export const demoNotifications = [
  { id: "n1", title: "مرحباً بك في دَرْب", body: "أنت تستخدم النسخة التجريبية. لا توجد رحلات حقيقية.", at: "اليوم" },
];
